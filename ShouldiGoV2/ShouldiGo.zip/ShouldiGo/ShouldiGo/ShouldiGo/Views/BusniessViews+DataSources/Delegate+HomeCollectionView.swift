//
//  Delegate+HomeCollectionView.swift
//  ShouldiGo
//
//  Created by Mohammed on 16/12/2020.
//

import UIKit

class HomeCollectionDelegate: NSObject, UICollectionViewDelegate{
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
    }
    
}
